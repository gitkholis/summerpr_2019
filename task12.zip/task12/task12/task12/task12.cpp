﻿#include "pch.h"
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>
#include <fstream>
#include <ctime>

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool is_declared(char i, vector<char> v) {										//проверяет, есть ли в v такой же символ i
	bool dec = false;
	for (char j : v) {
		dec = dec || (i == j);
	}
	return dec;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

string decode_string(string a, map <char, int> &cipher) {						//при помощи cipher переводит из буквенного вида в цифровой
	map <char, int> ::iterator it = cipher.begin();
	for (int i = 0; i < a.size(); i++) {
		it = cipher.find(a[i]);
		a[i] = it->second + '0';
	}
	return a;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int MyAtoi(string a) {															// переводит из строки в int
	int s = 0, d = 0;
	for (int i = a.size() - 1; i >= 0; i--) {
		s += (a[i] - 48)*pow(10, d);
		d++;
	}
	return s;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool same_val(map <char, int> cipher) {											//проверяет, есть ли в cipher повторяющиеся символы
	map <char, int> ::iterator it = cipher.begin();
	for (int i = 0; it != cipher.end(); it++, i++) {
		map <char, int> ::iterator it1 = cipher.begin();
		for (int j = 0; it1 != cipher.end(); it1++, j++) {
			if (it->second == it1->second && it1->first != it->first) return false;
		}
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void rec(string &a, string &b, string &c, map <char, int> &cipher) {			//основная рекурсивная функция
	string a_dec = decode_string(a, cipher);									//декодируем строки
	string b_dec = decode_string(b, cipher);
	string c_dec = decode_string(c, cipher);

	double aInt = MyAtoi(a_dec), bInt = MyAtoi(b_dec); double cInt = MyAtoi(c_dec);		//переводим их в int
	double expression;
	if (bInt != 0)
		expression = aInt / bInt;
	else expression = cInt + 1;															//если b==0, то автоматом неверная комбинация
	if (expression == cInt && same_val(cipher)) {										//если a/b==c и нет повторяющихся цифр в cipher, то ответ верный
		a = to_string((int)aInt), b = to_string((int)bInt), c = to_string((int)cInt);
		return;
	}
	else {																				//иначе переводим значения cipher в число
		int sum = 0;																	//например: "A" - 1, "B" - 2, "C" - 3 переводится в 123
		map <char, int> ::iterator it = cipher.begin();
		for (int i = 0; it != cipher.end(); it++, i++) {
			sum = sum + it->second*pow(10, cipher.size() - 1 - i);
		}
		sum++;																			//и увеличиваем на 1, чтобы было не ABC -> 123, а ABC->124 соответственно
		if (sum >= pow(10, max(a.size(), cipher.size()))) throw runtime_error("Нет решения");   //если значение очень большое, то решения нет
		map <char, int> ::iterator it1 = cipher.begin();
		int p = pow(10, cipher.size() - 1);
		for (int i = 0; it1 != cipher.end(); it1++, i++) {								//распределяем цифры обратно
			it1->second = sum / p;
			sum -= it1->second*p;
			p /= 10;
		}
	}
	rec(a, b, c, cipher);																//и делаем рекурсивный вызов
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void decode(string &a, string &b, string &c) {											//функция определения cipher и вызова rec
	if (a.size() < b.size()) throw runtime_error("Нет решения");
	string d = a + b + c;
	vector <char> carr;
	carr.push_back(a[0]);
	for (char i : d) {
		if (!is_declared(i, carr)) carr.push_back(i);
	}

	map <char, int> cipher;
	for (char i : carr) {
		cipher.insert(make_pair(i, 0));
	}
	rec(a, b, c, cipher);
	cout << a << endl;																	//вывод полученных данных
	cout << b << endl;
	cout << c << endl;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main() {
	setlocale(LC_ALL, "Russian");
	clock_t a, b;
	a = clock();
	try {
		char file[50] = "C:\\file.txt";
		ifstream fin(file);
		string a, b, c;
		fin >> a;
		fin >> b;
		fin >> c;
		fin.close();
		cout << "CRYPT >>> " << a << " / " << b << " = " << c << endl;
		decode(a, b, c);
	}
	catch (exception &e) {
		cout << e.what() << endl;
	}
	b = clock();
	// обработка разницы
	cout << "time = " << ((b - a) / (double)CLOCKS_PER_SEC) << endl;
	system("Pause");
	return 0;
}